# Colab cells (copy/paste into your notebook)

## A) Colab: mount Drive + pull latest + symlink models
```python
# MARKER:BEGIN-COLAB-SETUP
from google.colab import drive
drive.mount('/content/drive', force_remount=True)

# repo paths
REPO_URL = "https://github.com/SorretAI/aiqueue.git"
WORKDIR = "/content/aiqueue"
!rm -rf "$WORKDIR" && git clone "$REPO_URL" "$WORKDIR"
%cd $WORKDIR/infra/comfyui-docker

# persistent dirs on Drive
!mkdir -p /content/drive/MyDrive/AIQ/comfyui/{models,input,output}
!mkdir -p ./models ./input ./output
!rm -f ./models ./input ./output
!ln -s /content/drive/MyDrive/AIQ/comfyui/models ./models
!ln -s /content/drive/MyDrive/AIQ/comfyui/input  ./input
!ln -s /content/drive/MyDrive/AIQ/comfyui/output ./output
# MARKER:END-COLAB-SETUP
```

## B) Colab: run ComfyUI (CPU) without Docker
```python
# MARKER:BEGIN-COLAB-RUN
!pip -q install fastapi uvicorn==0.30.* gitpython

# Get ComfyUI
!rm -rf /content/ComfyUI && git clone --depth 1 https://github.com/comfyanonymous/ComfyUI /content/ComfyUI
%cd /content/ComfyUI
!pip -q install -r requirements.txt

# point dirs
import os
os.environ["COMFYUI_MODELS_DIR"]="/content/drive/MyDrive/AIQ/comfyui/models"
os.environ["COMFYUI_INPUT_DIR"]="/content/drive/MyDrive/AIQ/comfyui/input"
os.environ["COMFYUI_OUTPUT_DIR"]="/content/drive/MyDrive/AIQ/comfyui/output"

# run (CPU will be slow; good enough for node logic)
!python main.py --listen 0.0.0.0 --port 8188
# MARKER:END-COLAB-RUN
```

## C) Optional: ngrok public URL
```python
# MARKER:BEGIN-COLAB-NGROK
!pip -q install pyngrok
from pyngrok import ngrok
port = 8188
tunnel = ngrok.connect(port, "http")
print("Public URL:", tunnel.public_url)
# MARKER:END-COLAB-NGROK
```
