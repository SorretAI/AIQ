def test_adds_one():
    from ComfyUI.custom_nodes.MyNode import MyNode
    assert MyNode().run(41) == (42,)
