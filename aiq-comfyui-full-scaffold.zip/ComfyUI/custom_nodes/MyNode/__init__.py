# MARKER:BEGIN-NODE (sample)
class MyNode:
    @classmethod
    def INPUT_TYPES(s):
        return {"required": {"x": ("INT",)}}  # demo
    RETURN_TYPES = ("INT",)
    FUNCTION = "run"
    CATEGORY = "AIQ"

    def run(self, x: int):
        return (x + 1,)

NODE_CLASS_MAPPINGS = {"MyNode": MyNode}
# MARKER:END-NODE (sample)
