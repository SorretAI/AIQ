# ComfyUI Docker (AIQueue full scaffold)

## Quick Start
GPU:
```bash
docker compose -f docker-compose.yml up --build
```
CPU (old laptops):
```bash
docker compose -f docker-compose.cpu.yml up --build
```

## Models & IO
- Mounts `./models` -> `/data/models`
- Output to `./output`, input from `./input`

## Custom Nodes
Add repos to `custom_nodes.txt`. They clone/update on container start.

## CPU build (alternate)
```
docker build --build-arg BASE_IMAGE=pytorch/pytorch:2.3.1-cpu -t <you>/comfyui:cpu .
```

## GitHub Actions
Add repo secrets: `DOCKERHUB_USERNAME`, `DOCKERHUB_TOKEN`.
