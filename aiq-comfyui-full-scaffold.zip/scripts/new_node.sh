#!/usr/bin/env bash
# MARKER:BEGIN-NODE-GEN
set -e
name="${1:?usage: scripts/new_node.sh MyNodeName}"
pkg="ComfyUI/custom_nodes/${name}"
mkdir -p "$pkg/tests"
cat > "$pkg/__init__.py" <<'PY'
# MARKER:BEGIN-NODE
class MyNode:
    @classmethod
    def INPUT_TYPES(s):
        return {"required": {"x": ("INT",)}}  # demo
    RETURN_TYPES = ("INT",)
    FUNCTION = "run"
    CATEGORY = "AIQ"

    def run(self, x: int):
        return (x + 1,)

NODE_CLASS_MAPPINGS = {"MyNode": MyNode}
# MARKER:END-NODE
PY
cat > "$pkg/tests/test_node.py" <<'PY'
def test_adds_one():
    from ComfyUI.custom_nodes.MyNode import MyNode
    assert MyNode().run(41) == (42,)
PY
echo "Created $pkg"
# MARKER:END-NODE-GEN
