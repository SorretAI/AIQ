#!/usr/bin/env bash
set -euo pipefail

# MARKER:BEGIN-ENTRYPOINT
: "${PORT:=8188}"
: "${LISTEN:=0.0.0.0}"
: "${XFORMERS:=auto}"   # set to "disable" to skip xformers
: "${CLONE_NODES:=true}"

echo "[ComfyUI] Starting on ${LISTEN}:${PORT}"

if [[ "${CLONE_NODES}" == "true" && -f /opt/custom_nodes.txt ]]; then
  echo "[ComfyUI] Installing custom nodes from /opt/custom_nodes.txt"
  while IFS= read -r repo || [[ -n "$repo" ]]; do
    [[ -z "$repo" || "$repo" =~ ^# ]] && continue
    name=$(basename "$repo" .git)
    dest="/opt/ComfyUI/custom_nodes/${name}"
    if [[ -d "$dest/.git" ]]; then
      echo "[ComfyUI] Updating ${name}"
      git -C "$dest" pull --rebase || true
    else
      echo "[ComfyUI] Cloning ${name}"
      git clone "$repo" "$dest" || true
    fi
  done < /opt/custom_nodes.txt
fi

# xformers optional
if [[ "${XFORMERS}" == "auto" ]]; then
  echo "[ComfyUI] Using default torch/xformers from base image or requirements."
elif [[ "${XFORMERS}" == "disable" ]]; then
  echo "[ComfyUI] Skipping xformers."
fi

cd /opt/ComfyUI

# Run ComfyUI
exec python main.py --listen "$LISTEN" --port "$PORT"
# MARKER:END-ENTRYPOINT
