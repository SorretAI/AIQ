# ComfyUI Docker (AIQueue scaffold)

This folder builds a GPU-ready ComfyUI image.

## Build (GPU)
```bash
docker build -t your-dockerhub-username/comfyui:latest .
# or with compose
docker compose up --build
```

> Requires NVIDIA Container Toolkit on host. Test with `docker run --gpus all nvidia/cuda:12.1.1-base nvidia-smi`.

## CPU Variant
Use a CPU base image:
```bash
docker build --build-arg BASE_IMAGE=pytorch/pytorch:2.3.1-cpu -t your-dockerhub-username/comfyui:cpu .
```

## Models
Mount your models at `./models` (mapped to `/data/models`). Output goes to `./output`.

## Custom Nodes
Add repos to `custom_nodes.txt`. They will be cloned/updated on container start.

## Ports
Default UI at http://localhost:8188 (override with `PORT` env).

## Common Host Setup (Ubuntu)
```bash
sudo apt-get update && sudo apt-get install -y ca-certificates curl
sudo install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://nvidia.github.io/libnvidia-container/gpgkey | sudo gpg --dearmor -o /etc/apt/keyrings/nvidia-container-toolkit.gpg
curl -fsSL https://nvidia.github.io/libnvidia-container/stable/deb/nvidia-container-toolkit.list |       sed 's#deb https://#deb [signed-by=/etc/apt/keyrings/nvidia-container-toolkit.gpg] https://#g' |       sudo tee /etc/apt/sources.list.d/nvidia-container-toolkit.list
sudo apt-get update && sudo apt-get install -y nvidia-container-toolkit
sudo nvidia-ctk runtime configure --runtime=docker
sudo systemctl restart docker
```

## GitHub Actions: Push to Docker Hub
- Set secrets in your repo: `DOCKERHUB_USERNAME`, `DOCKERHUB_TOKEN`.
- On pushes to `main`, the workflow will build and push `latest` and `sha` tags.
